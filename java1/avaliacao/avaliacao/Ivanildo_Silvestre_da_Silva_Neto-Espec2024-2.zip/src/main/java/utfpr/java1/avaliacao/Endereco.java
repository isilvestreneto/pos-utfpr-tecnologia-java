// @author Ivanildo Silvestre da Silva Neto

package utfpr.java1.avaliacao;

public final class Endereco {
    private int num;
    private String rua;

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }
    
    
}
