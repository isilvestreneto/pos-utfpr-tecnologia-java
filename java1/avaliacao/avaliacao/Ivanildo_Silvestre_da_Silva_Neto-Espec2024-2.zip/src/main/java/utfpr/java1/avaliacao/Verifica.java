// @author Ivanildo Silvestre da Silva Neto

package utfpr.java1.avaliacao;

public interface Verifica {
    void validar();
}
